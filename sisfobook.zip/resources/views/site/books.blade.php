@extends('layouts.books') 
@section('content')
<ul>
    <ol>Nama : Mohammad Arief Lazuardi </ol>
    <ol>Kontak : h1101211048@student.untan.ac.id </ol>
    <ol>Alamat : Jl. Jeranding </ol>
    <ol>No HP : 081212121212</ol>
</ul>
@endsection
