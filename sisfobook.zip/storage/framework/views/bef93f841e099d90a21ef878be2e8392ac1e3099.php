<header class="bg-dark py-5">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-left   text-white">
                    <h1 class="display-4 fw-bolder">Arief Store</h1>
                    <p class="lead fw-normal text-white-50 mb-0">Kontak Kami</p>
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </header><?php /**PATH C:\laragon\www\sisfobook\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>