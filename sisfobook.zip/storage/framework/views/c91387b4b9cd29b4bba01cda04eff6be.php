
 
<?php $__env->startSection('title', 'Selamat Datang'); ?>
 
<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>
    <br>
    Back to Home
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<?php if($message = Session::get('success')): ?>
<div class="alert alert-success alert-dismissible">
<button type="button" class="close" data-dismiss="alert">&times;</button>
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<div class="pull-right mb-2">
    <a class="btn btn-success" href="<?php echo e(route('category.create')); ?>"> Tambahkan Kategori Baru</a>
</div>

<table class="table table-hover">
        <tr>
            <th>Nama Kategori</th>
            <th>Aksi</th>
        </tr>
        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($ct->category_name); ?></td>
            <td>
            <form action="<?php echo e(route('category.delete',$ct->id)); ?>" method="POST">
                <a href="<?php echo e(route('category.show',['id'=>$ct->id])); ?>" class="btn btn-sm btn-info">Detail</a>
                <a href="<?php echo e(route('category.edit',['id'=>$ct->id])); ?>" class="btn btn-sm btn-warning">Ubah</a>
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin ingin menghapus?')">Hapus</button>
            </form>
        </td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    
    <!-- <div class="form-group">
        <a href="category-update"><button class="btn btn-primary">Tambah Category</button></a>
    </div> -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.utama', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sisfobook\resources\views/category/index.blade.php ENDPATH**/ ?>