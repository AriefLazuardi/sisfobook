
<?php $__env->startSection('content'); ?>
<ul>
    <ol>Nama : Mohammad Arief Lazuardi </ol>
    <ol>Kontak : h1101211048@student.untan.ac.id </ol>
    <ol>Alamat : Jl. Jeranding </ol>
    <ol>No HP : 081212121212</ol>
</ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.books', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sisfobook\resources\views/site/kontak.blade.php ENDPATH**/ ?>