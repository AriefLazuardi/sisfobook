
 
<?php $__env->startSection('title', 'Selamat Datang'); ?>
 
<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>
    <br>
    Back to Home
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


    <ul>
        <?php foreach ($publisher as $pb) { ?>
            <li><?php echo $pb->publisher_name ?></li>
        <?php } ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.utama', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sisfobook\resources\views/publisher/index.blade.php ENDPATH**/ ?>