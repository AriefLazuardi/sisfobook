<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Web Saya</title>
</head>
<body>
    <h1><?= $searched_book['title']?></h1>
    <h3><?= $searched_book['author']?></3>
    <h5><?= $searched_book['year']?></h5>
    <p><?= $searched_book['publisher']?></p>
</body>
</html>
