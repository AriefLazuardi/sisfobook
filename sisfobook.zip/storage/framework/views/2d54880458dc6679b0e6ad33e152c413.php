


<?php $__env->startSection('title', 'Detail Kategori'); ?>


<?php $__env->startSection('sidebar'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">


    <div class="col-md-6">
        <div class="pull-right mb-2">
            <a class="btn btn-success" href="<?php echo e(route('category.index')); ?>"> Kembali</a>
        </div>
        <ul>
            <li>Nama Kategori: <?php echo e($category->category_name); ?></li>
            <li>Deskripsi: <?php echo e($category->description); ?></li>
            <img src="<?php echo e(asset('cover/'.$category->file_cover)); ?>" alt="image" width="200">

        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.utama', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sisfobook\resources\views/category/show.blade.php ENDPATH**/ ?>