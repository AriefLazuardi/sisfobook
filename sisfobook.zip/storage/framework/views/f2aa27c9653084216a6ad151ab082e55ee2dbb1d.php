 

<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>
    <br>
    Back to Home
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
    <p>All About Us. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer neque urna, posuere nec felis in, vulputate auctor arcu. Aliquam ut lectus et nisi eleifend vestibulum sed vitae risus. Fusce id euismod enim. Praesent molestie pharetra elit eget malesuada. Suspendisse consectetur odio et placerat interdum. Nullam et fermentum lacus. Etiam id orci et leo dapibus sodales a ac ex. Aenean viverra aliquet neque, nec molestie arcu feugiat ac. Aenean malesuada vitae odio sit amet tincidunt.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.utama', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sisfobook\resources\views/site/about.blade.php ENDPATH**/ ?>